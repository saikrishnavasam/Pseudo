package com.cg.returnGoods.service;

import java.util.List;

import com.cg.returnGoods.entity.Return;

public interface IReturnService {
	
	public List<Return> getAllReturnDetails();
	
	public int addrecordtoreturn(int temp);
	
	public Return checkstatus(int orderid);
	
	public List<Return> getreturngoods();

}

