package com.cg.returnGoods.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.cg.returnGoods.entity.Order;
import com.cg.returnGoods.dao.IOrderDao;
import com.cg.returnGoods.dao.IReturnDao;
import com.cg.returnGoods.entity.Return;

public class ReturnService implements IReturnService {

	@Autowired
	IReturnDao returnDao;
	
	@Autowired
	IOrderDao orderDao;
	
	@Override
	public List<Return> getAllReturnDetails() {
		return returnDao.findAll();
	}

	@Override
	public int addrecordtoreturn(int temp) { ///////////////Check this//////////////////
		Return myreturn = new Return(temp, null, null, null, null);
		
		Order myorder=orderDao.findById(temp).get();
		
		myreturn.setOrder(myorder);
		myreturn.setPickupDate(new Date());
		
		myreturn.setReturnStatus("success");
		
		
	
		
	   returnDao.save(myreturn);
	   
	   return myreturn.getReturnId();
	   
	}

	@Override
	public Return checkstatus(int orderid) {

		Order myorder=orderDao.findById(orderid).get();
		List<Return> prodreturn = returnDao.findAll();
		for(Return ret:prodreturn)
		{
			if(((Order) ret.getOrder()).getOrderId()==orderid)
			{
				return ret;
			}
		}
		return null;
	}

//	@Override
//	public boolean refundMoney(int orderId) {
//		// TODO Auto-generated method stub
//		return false;
//	}

	@Override
	public List<Return> getreturngoods() {
		return returnDao.findAll();
		}


}

