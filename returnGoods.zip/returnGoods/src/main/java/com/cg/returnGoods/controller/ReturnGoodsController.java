package com.cg.returnGoods.controller;

import java.util.List;

import javax.persistence.criteria.Order;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.cg.returnGoods.entity.Return;
import com.cg.returnGoods.service.IOrderService;
import com.cg.returnGoods.service.IProductImageService;
import com.cg.returnGoods.service.IReturnService;

public class ReturnGoodsController {
	@Autowired
	private IOrderService orderService;
	
	@Autowired
	private IReturnService returnService;

	@Autowired
	private IProductImageService productImageService;
	
	@GetMapping("/myorders")
	public ResponseEntity<List<Order>> getAllOrders(){
		List<Order> orders= orderService.getAllOrders();
		if (orders==null) {
			new ResponseEntity("No account found", HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<Order>>(orders, HttpStatus.OK);
	}
	
	@GetMapping("/myorders/{orderId}")
	public ResponseEntity<Integer> addrecordtoreturn(@PathVariable ("orderId") int orderid ) {
		System.out.println(orderid+"printing temp");
		 int myret=returnService.addrecordtoreturn(orderid);
		
		 return new ResponseEntity<Integer>(myret, HttpStatus.OK);
		 
	}
	
//	@GetMapping("/myOrder/verify/{orderId}/refundMoney")
//	public ResponseEntity<Boolean> refundMoney(@PathVariable("orderId") int orderId){
//		
//		boolean refundStatus = returnService.refundMoney(orderId);
//		
//		return new ResponseEntity<Boolean>(refundStatus, HttpStatus.OK);
//	}

	@GetMapping("/getreturngoods")
	public ResponseEntity<List<Return>> getreturngoods() {
		List<Return> orders= returnService.getreturngoods();
		

		return new ResponseEntity<List<Return>>(orders, HttpStatus.OK);
	}
	
	
	
}
