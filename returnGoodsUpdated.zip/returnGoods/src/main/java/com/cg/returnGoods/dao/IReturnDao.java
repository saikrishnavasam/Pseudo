package com.cg.returnGoods.dao;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.returnGoods.entity.Return;

@Repository("returnDao")
@Transactional
public interface IReturnDao extends JpaRepository<Return, Integer> {

}
