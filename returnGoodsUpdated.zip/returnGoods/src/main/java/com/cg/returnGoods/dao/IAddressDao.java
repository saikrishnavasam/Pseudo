package com.cg.returnGoods.dao;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.returnGoods.entity.Address;


@Repository("addressDao")
@Transactional
public interface IAddressDao extends JpaRepository<Address,Integer> {

	
}