package com.cg.returnGoods.service;

import java.util.List;

import javax.persistence.criteria.Order;


public interface IOrderService {
	public List<Order> getOrdersForCustomer( int custId);
	List<Order> getAllOrders();
	public Order findOrderById(int orderId);
}
