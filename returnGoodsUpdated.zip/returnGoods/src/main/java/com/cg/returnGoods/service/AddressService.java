package com.cg.returnGoods.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.cg.returnGoods.dao.IAddressDao;
import com.cg.returnGoods.dao.ICustomerDao;
import com.cg.returnGoods.entity.Address;
import com.cg.returnGoods.entity.Customer;



public class AddressService {
	@Autowired

	IAddressDao addressDao;
	@Autowired
	
	ICustomerDao customerDao;

	//Get all addresses
	
	//@Override
	public List<Address> getAllAddresses() {

		List<Address> add=addressDao.findAll();
		System.out.println("Service"+add);
		return addressDao.findAll();

	}

	
	//@Override
	public List<Address> createAddress(Address address ,String customerMail) {
		
		List<Customer> customers=customerDao.findAll();
		Customer customer=customerDao.getByEmailId(customerMail);
		
		
		customer=customerDao.getByEmailId(customerMail);
		//addressDao.save(address) ;
		customer.getAddresses().add(address);
		//System.out.println(customer);
		customerDao.save(customer);
		
		
		 return customer.getAddresses();
	}
	
	
	//@Override
	public Address createAddress(Address address) {
		
		return addressDao.save(address) ;
	}

		//@Override
		public List<Address> updateAddress(Address address) {
		addressDao.save(address);
		
		return addressDao.findAll();
		}

}
