package com.cg.returnGoods.service;

public interface IProductImageService {

}
