package com.cg.returnGoods.dao;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.returnGoods.entity.Customer;


@Repository("customerDao")
@Transactional
public interface ICustomerDao  extends JpaRepository<Customer,Integer> {
	@Query("from Customer where customer_id=:customerId")
	Customer getByCustomer(@Param("customerId") Integer custId);




}
